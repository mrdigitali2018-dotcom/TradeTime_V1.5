package com.mrdigitali.tradetime;
import java.time.*;
public final class Session {
 public enum S { GREEN,YELLOW,RED }
 public static boolean weekend(LocalDateTime n){DayOfWeek d=n.getDayOfWeek();return d==DayOfWeek.SATURDAY||d==DayOfWeek.SUNDAY;}
 public static S status(LocalDateTime n){return weekend(n)?S.RED:status(n.getHour()*60+n.getMinute());}
 public static S status(int m){if((m>=180&&m<210)||(m>=630&&m<810)||(m>=960&&m<1110))return S.GREEN;if((m>=210&&m<630)||(m>=1110&&m<1410))return S.YELLOW;return S.RED;}
 public static S sessionStatus(LocalDateTime n,int start,int end){if(weekend(n))return S.RED;int m=n.getHour()*60+n.getMinute();if(m>=start&&m<end)return S.GREEN;if(m<start)return S.YELLOW;return S.RED;}
 public static String statusText(S s,boolean fa){if(s==S.GREEN)return fa?"فعال":"Active";if(s==S.YELLOW)return fa?"به‌زودی":"Soon";return fa?"بسته":"Closed";}
 public static String emoji(S s){return s==S.GREEN?"🟢":s==S.YELLOW?"🟡":"🔴";}
 public static String hm(LocalDateTime t){return String.format("%02d:%02d",t.getHour(),t.getMinute());}
 public static LocalDateTime nextHour(LocalDateTime n){return n.withMinute(0).withSecond(0).withNano(0).plusHours(1);}
 public static LocalDateTime previousHour(LocalDateTime n){return n.withMinute(0).withSecond(0).withNano(0);}
 public static String remaining(LocalDateTime n){long s=Duration.between(n,nextHour(n)).getSeconds();return String.format("%02d:%02d:%02d",s/3600,(s%3600)/60,s%60);}
}
