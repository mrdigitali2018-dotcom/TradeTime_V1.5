package com.mrdigitali.tradetime;
import android.content.*;
public class BootReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){AlarmScheduler.all(c);if(Prefs.notify(c)) c.startForegroundService(new Intent(c,SessionNotificationService.class));}}
