package com.mrdigitali.tradetime;
import android.app.*;import android.content.*;import android.os.Build;import java.util.Calendar;
public final class AlarmScheduler {
 public static void all(Context c){for(int h=0;h<24;h++) schedule(c,h);}
 public static void schedule(Context c,int h){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); PendingIntent pi=pi(c,h); am.cancel(pi); if(!Prefs.alarm(c,h))return; Calendar cal=Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY,h);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0); if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_YEAR,1); while(cal.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY||cal.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY)cal.add(Calendar.DAY_OF_YEAR,1); if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi); else if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi); else am.setExact(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi); }
 static PendingIntent pi(Context c,int h){return PendingIntent.getBroadcast(c,100+h,new Intent(c,AlarmReceiver.class).putExtra("hour",h),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
}
