package com.mrdigitali.tradetime;
import android.content.*;import android.os.*;import java.time.LocalDateTime;
public class AlarmReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){int h=i.getIntExtra("hour",-1);if(h>=0) {if(!Session.weekend(LocalDateTime.now()) && Prefs.alarm(c,h))c.startForegroundService(new Intent(c,AlarmPlaybackService.class).putExtra("hour",h));AlarmScheduler.schedule(c,h);}}}
