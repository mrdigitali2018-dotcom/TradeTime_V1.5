package com.mrdigitali.tradetime;

import android.content.Context;
import android.net.Uri;

public final class Prefs {
    private static final String P="trade_time";
    private static android.content.SharedPreferences p(Context c){return c.getSharedPreferences(P,Context.MODE_PRIVATE);}
    public static boolean fa(Context c){return p(c).getString("lang","fa").equals("fa");}
    public static void lang(Context c, boolean fa){p(c).edit().putString("lang",fa?"fa":"en").apply();}
    public static boolean notify(Context c){return p(c).getBoolean("notify",true);}
    public static void notify(Context c,boolean v){p(c).edit().putBoolean("notify",v).apply();}
    public static boolean events(Context c){return p(c).getBoolean("events",true);}
    public static void events(Context c,boolean v){p(c).edit().putBoolean("events",v).apply();}
    public static boolean alarm(Context c,int h){return p(c).getBoolean("alarm"+h,false);}
    public static void alarm(Context c,int h,boolean v){p(c).edit().putBoolean("alarm"+h,v).apply();}
    public static String sound(Context c,int h){return p(c).getString("sound"+h,null);}
    public static void sound(Context c,int h,String v){p(c).edit().putString("sound"+h,v).apply();}
    public static String note(Context c,int h){return p(c).getString("note"+h,"");}
    public static void note(Context c,int h,String v){p(c).edit().putString("note"+h,v).apply();}
    public static String defaultSound(Context c){return p(c).getString("defaultSound",null);}
    public static void defaultSound(Context c,String v){p(c).edit().putString("defaultSound",v).apply();}
    public static Uri uri(Context c,String s){return s==null?null:Uri.parse(s);}
}
